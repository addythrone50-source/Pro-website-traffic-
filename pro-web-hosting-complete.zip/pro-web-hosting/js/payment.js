// Payment Page JavaScript

// Service data mapping
const serviceData = {
    // Traffic services
    organic: { name: "Organic Web Visitors", description: "Up to 10,000 visitors" },
    analytics: { name: "Real-time Analytics", description: "Advanced analytics suite" },
    bounce: { name: "Bounce Rate Reduction", description: "Engagement optimization" },
    geo: { name: "GEO Targeted Traffic", description: "Targeted by location" },
    niche: { name: "Niche-Specific Visitors", description: "Niche audience targeting" },
    time: { name: "Time-On-Site Optimization", description: "Engagement optimization" },
    
    // Hosting services
    shared: { name: "Shared Hosting", description: "Perfect for small websites" },
    vps: { name: "VPS Hosting", description: "Scalable virtual private server" },
    dedicated: { name: "Dedicated Server", description: "Full server resources" },
    
    // Proxy services
    residential: { name: "Residential Proxy", description: "High-quality residential IPs" },
    datacenter: { name: "Datacenter Proxy", description: "Fast datacenter proxies" },
    mobile: { name: "Mobile Proxy", description: "Mobile carrier IPs" }
};

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    initPaymentPage();
    initPaymentProcess();
    initOTPModal();
});

// Initialize payment page
function initPaymentPage() {
    // Check for URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const service = urlParams.get('service');
    const price = urlParams.get('price');
    const type = urlParams.get('type');
    
    if (service && price) {
        showCurrentOrder(service, price, type);
    }
}

// Show current order
function showCurrentOrder(serviceId, price, type) {
    const currentOrderSection = document.getElementById('currentOrder');
    const serviceName = document.getElementById('serviceName');
    const serviceDescription = document.getElementById('serviceDescription');
    const servicePrice = document.getElementById('servicePrice');
    const subtotal = document.getElementById('subtotal');
    const totalAmount = document.getElementById('totalAmount');
    
    if (currentOrderSection && serviceName && serviceDescription && servicePrice) {
        const service = serviceData[serviceId];
        if (service) {
            serviceName.textContent = service.name;
            serviceDescription.textContent = service.description;
            servicePrice.textContent = `$${price}`;
            subtotal.textContent = `$${price}`;
            totalAmount.textContent = `$${price}`;
            
            currentOrderSection.style.display = 'block';
        }
    }
}

// Initialize payment process
function initPaymentProcess() {
    const processButton = document.getElementById('processPayment');
    if (processButton) {
        processButton.addEventListener('click', startPaymentProcess);
    }
}

// Start payment process
function startPaymentProcess() {
    const processButton = document.getElementById('processPayment');
    const statusReady = document.getElementById('statusReady');
    const statusConnecting = document.getElementById('statusConnecting');
    const statusRequesting = document.getElementById('statusRequesting');
    const statusSuccess = document.getElementById('statusSuccess');
    
    // Disable button
    processButton.disabled = true;
    processButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
    
    // Step 1: Show connecting status
    statusReady.style.display = 'none';
    statusConnecting.style.display = 'flex';
    
    setTimeout(() => {
        // Step 2: Show requesting payment status
        statusConnecting.style.display = 'none';
        statusRequesting.style.display = 'flex';
        
        setTimeout(() => {
            // Step 3: Show success and request OTP
            statusRequesting.style.display = 'none';
            statusSuccess.style.display = 'flex';
            
            // Show OTP modal after a brief delay
            setTimeout(() => {
                showOTPModal();
            }, 1000);
            
        }, 5000); // 25s total - 20s = 5s for requesting
        
    }, 20000); // 20s for connecting
}

// Initialize OTP modal
function initOTPModal() {
    const verifyButton = document.getElementById('verifyOtp');
    const cancelButton = document.getElementById('cancelOtp');
    const otpInput = document.getElementById('otpInput');
    
    if (verifyButton) {
        verifyButton.addEventListener('click', verifyOTP);
    }
    
    if (cancelButton) {
        cancelButton.addEventListener('click', hideOTPModal);
    }
    
    if (otpInput) {
        otpInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                verifyOTP();
            }
        });
    }
}

// Show OTP modal
function showOTPModal() {
    const otpModal = document.getElementById('otpModal');
    if (otpModal) {
        otpModal.style.display = 'flex';
        
        // Focus on input
        const otpInput = document.getElementById('otpInput');
        if (otpInput) {
            setTimeout(() => otpInput.focus(), 100);
        }
    }
}

// Hide OTP modal
function hideOTPModal() {
    const otpModal = document.getElementById('otpModal');
    if (otpModal) {
        otpModal.style.display = 'none';
    }
    
    // Reset payment process
    resetPaymentProcess();
}

// Verify OTP
function verifyOTP() {
    const otpInput = document.getElementById('otpInput');
    const verifyButton = document.getElementById('verifyOtp');
    
    if (!otpInput || !verifyButton) return;
    
    const enteredOTP = otpInput.value.trim();
    const correctOTP = '123456';
    
    // Show loading state
    verifyButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verifying...';
    verifyButton.disabled = true;
    
    setTimeout(() => {
        if (enteredOTP === correctOTP) {
            // Success
            showPaymentSuccess();
            hideOTPModal();
        } else {
            // Error
            showOTPError();
            verifyButton.innerHTML = 'Verify';
            verifyButton.disabled = false;
        }
    }, 2000);
}

// Show OTP error
function showOTPError() {
    const otpInput = document.getElementById('otpInput');
    if (otpInput) {
        otpInput.style.borderColor = '#ef4444';
        otpInput.style.backgroundColor = '#fef2f2';
        
        // Create error message
        let errorMsg = document.querySelector('.otp-error');
        if (!errorMsg) {
            errorMsg = document.createElement('p');
            errorMsg.className = 'otp-error';
            errorMsg.style.color = '#ef4444';
            errorMsg.style.fontSize = '0.8rem';
            errorMsg.style.marginTop = '0.5rem';
            otpInput.parentNode.appendChild(errorMsg);
        }
        errorMsg.textContent = 'Invalid OTP. Please try again.';
        
        // Reset after 3 seconds
        setTimeout(() => {
            otpInput.style.borderColor = '#e5e7eb';
            otpInput.style.backgroundColor = 'white';
            if (errorMsg) errorMsg.remove();
        }, 3000);
    }
}

// Show payment success
function showPaymentSuccess() {
    // Update account stats
    updateAccountStats();
    
    // Add new order to history
    addOrderToHistory();
    
    // Show success message
    showSuccessNotification();
    
    // Reset current order
    const currentOrder = document.getElementById('currentOrder');
    if (currentOrder) {
        currentOrder.style.display = 'none';
    }
    
    // Reset payment process
    resetPaymentProcess();
}

// Update account stats
function updateAccountStats() {
    const totalSpentElement = document.querySelector('.account-stats .amount');
    const activeServicesElement = document.querySelector('.account-stats .count');
    
    if (totalSpentElement) {
        const currentAmount = parseFloat(totalSpentElement.textContent.replace('$', ''));
        const urlParams = new URLSearchParams(window.location.search);
        const newAmount = parseFloat(urlParams.get('price')) || 0;
        const updatedAmount = currentAmount + newAmount;
        totalSpentElement.textContent = `$${updatedAmount.toFixed(2)}`;
    }
    
    if (activeServicesElement) {
        const currentServices = parseInt(activeServicesElement.textContent);
        activeServicesElement.textContent = (currentServices + 1).toString();
    }
}

// Add order to history
function addOrderToHistory() {
    const ordersList = document.querySelector('.orders-list');
    const urlParams = new URLSearchParams(window.location.search);
    const serviceId = urlParams.get('service');
    const price = urlParams.get('price');
    
    if (ordersList && serviceId && price) {
        const service = serviceData[serviceId];
        if (service) {
            const now = new Date();
            const dateStr = now.toLocaleDateString('en-GB', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
            });
            const timeStr = now.toLocaleTimeString('en-GB', { 
                hour: '2-digit', 
                minute: '2-digit' 
            });
            
            const newOrder = document.createElement('div');
            newOrder.className = 'order-item';
            newOrder.innerHTML = `
                <div class="order-info">
                    <div class="order-icon">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <div class="order-details">
                        <h4>${service.name}</h4>
                        <p>${service.description}</p>
                        <span class="order-date">${dateStr} - ${timeStr} GMT</span>
                    </div>
                </div>
                <div class="order-amount">
                    <span class="amount">$${price}.00</span>
                    <span class="status completed">Completed</span>
                </div>
            `;
            
            // Add to top of list
            ordersList.insertBefore(newOrder, ordersList.firstChild);
        }
    }
}

// Show success notification
function showSuccessNotification() {
    const notification = document.createElement('div');
    notification.className = 'success-notification';
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-check-circle"></i>
            <div>
                <h4>Payment Successful!</h4>
                <p>Your service has been activated and is ready to use.</p>
            </div>
        </div>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: white;
        border: 1px solid #16a34a;
        border-radius: 15px;
        padding: 1rem;
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        z-index: 10001;
        min-width: 300px;
        animation: slideIn 0.3s ease;
    `;
    
    const content = notification.querySelector('.notification-content');
    content.style.cssText = `
        display: flex;
        align-items: center;
        gap: 1rem;
    `;
    
    const icon = notification.querySelector('i');
    icon.style.cssText = `
        color: #16a34a;
        font-size: 2rem;
    `;
    
    const title = notification.querySelector('h4');
    title.style.cssText = `
        color: #16a34a;
        margin: 0 0 0.3rem 0;
        font-size: 1rem;
    `;
    
    const text = notification.querySelector('p');
    text.style.cssText = `
        color: #666;
        margin: 0;
        font-size: 0.9rem;
    `;
    
    // Add animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(notification);
    
    // Remove after 5 seconds
    setTimeout(() => {
        notification.style.animation = 'slideIn 0.3s ease reverse';
        setTimeout(() => {
            notification.remove();
            style.remove();
        }, 300);
    }, 5000);
}

// Reset payment process
function resetPaymentProcess() {
    const processButton = document.getElementById('processPayment');
    const statusReady = document.getElementById('statusReady');
    const statusConnecting = document.getElementById('statusConnecting');
    const statusRequesting = document.getElementById('statusRequesting');
    const statusSuccess = document.getElementById('statusSuccess');
    
    if (processButton) {
        processButton.disabled = false;
        processButton.innerHTML = '<i class="fas fa-credit-card"></i> Process Payment';
    }
    
    // Reset status displays
    if (statusReady) statusReady.style.display = 'flex';
    if (statusConnecting) statusConnecting.style.display = 'none';
    if (statusRequesting) statusRequesting.style.display = 'none';
    if (statusSuccess) statusSuccess.style.display = 'none';
    
    // Clear OTP input
    const otpInput = document.getElementById('otpInput');
    if (otpInput) {
        otpInput.value = '';
        otpInput.style.borderColor = '#e5e7eb';
        otpInput.style.backgroundColor = 'white';
    }
}

// Export functions for admin panel
window.PaymentAdmin = {
    getOrderHistory: () => {
        const orders = [];
        const orderItems = document.querySelectorAll('.order-item');
        orderItems.forEach(item => {
            const name = item.querySelector('.order-details h4').textContent;
            const amount = item.querySelector('.order-amount .amount').textContent;
            const date = item.querySelector('.order-date').textContent;
            orders.push({ name, amount, date });
        });
        return orders;
    },
    
    getAccountStats: () => {
        const totalSpent = document.querySelector('.account-stats .amount')?.textContent || '$0';
        const activeServices = document.querySelector('.account-stats .count')?.textContent || '0';
        return { totalSpent, activeServices };
    }
};

