// Admin Panel JavaScript

// Admin credentials (DO NOT expose in production)
const ADMIN_PASSWORD = '123356789';

// Pricing data storage
let pricingData = {
    sparkTraffic: {
        organic: { name: "Organic Web Visitors", price: 49, description: "Up to 10,000 visitors" },
        analytics: { name: "Real-time Analytics", price: 29, description: "Advanced analytics suite" },
        bounce: { name: "Bounce Rate Reduction", price: 39, description: "Engagement optimization" },
        geo: { name: "GEO Targeted Traffic", price: 59, description: "Targeted by location" },
        niche: { name: "Niche-Specific Visitors", price: 69, description: "Niche audience targeting" },
        time: { name: "Time-On-Site Optimization", price: 45, description: "Engagement optimization" }
    },
    hosting: {
        shared: { name: "Shared Hosting", price: 9.99, description: "Perfect for small websites" },
        vps: { name: "VPS Hosting", price: 29.99, description: "Scalable virtual private server" },
        dedicated: { name: "Dedicated Server", price: 99.99, description: "Full server resources" }
    },
    proxy: {
        residential: { name: "Residential Proxy", price: 79.99, description: "High-quality residential IPs" },
        datacenter: { name: "Datacenter Proxy", price: 39.99, description: "Fast datacenter proxies" },
        mobile: { name: "Mobile Proxy", price: 149.99, description: "Mobile carrier IPs" }
    }
};

// Initialize admin panel
document.addEventListener('DOMContentLoaded', function() {
    initLogin();
    initNavigation();
    initPricingManagement();
    initSettings();
    
    // Check if already logged in
    if (localStorage.getItem('adminLoggedIn') === 'true') {
        showDashboard();
    }
});

// Initialize login functionality
function initLogin() {
    const loginForm = document.getElementById('loginForm');
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('adminPassword');
    
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    if (togglePassword && passwordInput) {
        togglePassword.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            
            const icon = this.querySelector('i');
            icon.className = type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
        });
    }
    
    // Logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
}

// Handle login
function handleLogin(e) {
    e.preventDefault();
    
    const passwordInput = document.getElementById('adminPassword');
    const loginError = document.getElementById('loginError');
    const loginBtn = document.querySelector('.btn-login');
    
    if (!passwordInput || !loginError || !loginBtn) return;
    
    const enteredPassword = passwordInput.value.trim();
    
    // Show loading state
    loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Authenticating...';
    loginBtn.disabled = true;
    loginError.textContent = '';
    
    setTimeout(() => {
        if (enteredPassword === ADMIN_PASSWORD) {
            // Success
            localStorage.setItem('adminLoggedIn', 'true');
            showDashboard();
        } else {
            // Error
            loginError.textContent = 'Invalid password. Please try again.';
            passwordInput.value = '';
            passwordInput.focus();
        }
        
        // Reset button
        loginBtn.innerHTML = '<i class="fas fa-sign-in-alt"></i> Access Admin Panel';
        loginBtn.disabled = false;
    }, 1500);
}

// Handle logout
function handleLogout() {
    localStorage.removeItem('adminLoggedIn');
    showLogin();
}

// Show dashboard
function showDashboard() {
    const loginScreen = document.getElementById('adminLogin');
    const dashboard = document.getElementById('adminDashboard');
    
    if (loginScreen && dashboard) {
        loginScreen.style.display = 'none';
        dashboard.style.display = 'block';
        
        // Load pricing data
        loadPricingData();
        
        // Initialize analytics chart
        initAnalyticsChart();
    }
}

// Show login
function showLogin() {
    const loginScreen = document.getElementById('adminLogin');
    const dashboard = document.getElementById('adminDashboard');
    
    if (loginScreen && dashboard) {
        loginScreen.style.display = 'flex';
        dashboard.style.display = 'none';
        
        // Clear password field
        const passwordInput = document.getElementById('adminPassword');
        if (passwordInput) {
            passwordInput.value = '';
        }
    }
}

// Initialize navigation
function initNavigation() {
    const navButtons = document.querySelectorAll('.nav-btn');
    
    navButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const sectionId = this.dataset.section;
            showSection(sectionId);
            
            // Update active button
            navButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

// Show section
function showSection(sectionId) {
    const sections = document.querySelectorAll('.admin-section');
    
    sections.forEach(section => {
        section.classList.remove('active');
    });
    
    const targetSection = document.getElementById(sectionId + 'Section');
    if (targetSection) {
        targetSection.classList.add('active');
    }
}

// Initialize pricing management
function initPricingManagement() {
    loadPricingData();
    
    // Add event listeners for update buttons
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('btn-update-price')) {
            const serviceId = e.target.dataset.service;
            const priceInput = e.target.parentNode.querySelector('.price-input');
            const newPrice = parseFloat(priceInput.value);
            
            if (newPrice && newPrice > 0) {
                updatePrice(serviceId, newPrice, e.target);
            }
        }
    });
}

// Load pricing data
function loadPricingData() {
    const sparkTrafficContainer = document.getElementById('sparkTrafficPricing');
    
    if (sparkTrafficContainer) {
        sparkTrafficContainer.innerHTML = Object.keys(pricingData.sparkTraffic).map(serviceId => {
            const service = pricingData.sparkTraffic[serviceId];
            return `
                <div class="pricing-item">
                    <div class="service-info">
                        <h4>${service.name}</h4>
                        <p>${service.description}</p>
                    </div>
                    <div class="price-controls">
                        <input type="number" class="price-input" value="${service.price}" min="1" step="0.01">
                        <button class="btn-update-price" data-service="spark-${serviceId}">Update</button>
                    </div>
                </div>
            `;
        }).join('');
    }
}

// Update price
function updatePrice(serviceId, newPrice, button) {
    // Show loading state
    const originalText = button.textContent;
    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    button.disabled = true;
    
    setTimeout(() => {
        // Update pricing data
        if (serviceId.startsWith('spark-')) {
            const sparkServiceId = serviceId.replace('spark-', '');
            if (pricingData.sparkTraffic[sparkServiceId]) {
                pricingData.sparkTraffic[sparkServiceId].price = newPrice;
                
                // Update external pricing if available
                if (window.SparkTrafficAdmin && window.SparkTrafficAdmin.updateServicePricing) {
                    window.SparkTrafficAdmin.updateServicePricing(sparkServiceId, newPrice);
                }
            }
        }
        
        // Show success state
        button.innerHTML = '<i class="fas fa-check"></i> Updated';
        button.classList.add('success');
        
        // Show success notification
        showNotification('Price updated successfully!', 'success');
        
        // Reset button after 2 seconds
        setTimeout(() => {
            button.innerHTML = originalText;
            button.disabled = false;
            button.classList.remove('success');
        }, 2000);
        
    }, 1000);
}

// Show notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#10b981' : '#2563eb'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        z-index: 10001;
        font-weight: 500;
        animation: slideInRight 0.3s ease;
    `;
    notification.textContent = message;
    
    // Add animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideInRight 0.3s ease reverse';
        setTimeout(() => {
            notification.remove();
            style.remove();
        }, 300);
    }, 3000);
}

// Initialize settings
function initSettings() {
    const changePasswordBtn = document.querySelector('.btn-change-password');
    const backupBtn = document.querySelector('.btn-backup');
    
    if (changePasswordBtn) {
        changePasswordBtn.addEventListener('click', function() {
            const newPasswordInput = document.getElementById('newPassword');
            const newPassword = newPasswordInput.value.trim();
            
            if (newPassword.length < 6) {
                alert('Password must be at least 6 characters long');
                return;
            }
            
            // In a real application, this would update the password securely
            showNotification('Password updated successfully!', 'success');
            newPasswordInput.value = '';
        });
    }
    
    if (backupBtn) {
        backupBtn.addEventListener('click', function() {
            // Simulate backup download
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
            this.disabled = true;
            
            setTimeout(() => {
                // Create and download backup file
                const backupData = {
                    timestamp: new Date().toISOString(),
                    pricing: pricingData,
                    settings: {
                        adminEmail: 'admin@prowebhosting.com',
                        emailNotifications: true,
                        maintenanceMode: false
                    }
                };
                
                const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `prowebhosting-backup-${new Date().toISOString().split('T')[0]}.json`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                
                this.innerHTML = '<i class="fas fa-download"></i> Download Backup';
                this.disabled = false;
                
                showNotification('Backup downloaded successfully!', 'success');
            }, 2000);
        });
    }
}

// Initialize analytics chart
function initAnalyticsChart() {
    const canvas = document.getElementById('revenueChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // Set canvas size
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    
    drawRevenueChart(ctx, canvas.width, canvas.height);
}

// Draw revenue chart
function drawRevenueChart(ctx, width, height) {
    ctx.clearRect(0, 0, width, height);
    
    // Sample revenue data for the last 12 months
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const revenue = [1200, 1450, 1800, 2100, 1950, 2300, 2650, 2400, 2800, 2950, 2700, 2847];
    
    const maxRevenue = Math.max(...revenue);
    const stepX = width / (revenue.length - 1);
    const chartHeight = height - 60; // Leave space for labels
    
    // Draw grid lines
    ctx.strokeStyle = '#e5e7eb';
    ctx.lineWidth = 1;
    
    for (let i = 0; i <= 5; i++) {
        const y = (chartHeight / 5) * i + 20;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
    }
    
    // Draw revenue line
    ctx.strokeStyle = '#2563eb';
    ctx.lineWidth = 3;
    ctx.beginPath();
    
    revenue.forEach((value, index) => {
        const x = index * stepX;
        const y = chartHeight - (value / maxRevenue) * (chartHeight - 40) + 20;
        
        if (index === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });
    
    ctx.stroke();
    
    // Draw points
    ctx.fillStyle = '#2563eb';
    revenue.forEach((value, index) => {
        const x = index * stepX;
        const y = chartHeight - (value / maxRevenue) * (chartHeight - 40) + 20;
        
        ctx.beginPath();
        ctx.arc(x, y, 5, 0, Math.PI * 2);
        ctx.fill();
    });
    
    // Draw labels
    ctx.fillStyle = '#666';
    ctx.font = '12px Poppins';
    ctx.textAlign = 'center';
    
    months.forEach((month, index) => {
        const x = index * stepX;
        ctx.fillText(month, x, height - 10);
    });
    
    // Draw revenue values
    ctx.textAlign = 'left';
    for (let i = 0; i <= 5; i++) {
        const value = Math.round((maxRevenue / 5) * (5 - i));
        const y = (chartHeight / 5) * i + 25;
        ctx.fillText(`$${value}`, 5, y);
    }
}

// Export admin functions
window.AdminPanel = {
    updatePrice,
    showNotification,
    getPricingData: () => pricingData
};

