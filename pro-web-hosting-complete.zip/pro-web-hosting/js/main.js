// Main JavaScript for Pro Web Hosting

// Sample reviews data
const reviewsData = [
    {
        name: "John Smith",
        service: "hosting",
        rating: 5,
        text: "Excellent hosting service! My website has been running smoothly for over a year with 99.9% uptime. The support team is incredibly responsive and knowledgeable.",
        avatar: "JS"
    },
    {
        name: "Sarah Johnson",
        service: "traffic",
        rating: 5,
        text: "The traffic generation service exceeded my expectations. I saw a 300% increase in organic visitors within the first month. Highly recommended!",
        avatar: "SJ"
    },
    {
        name: "Mike Chen",
        service: "proxy",
        rating: 5,
        text: "Their residential proxy network is top-notch. Fast, reliable, and secure. Perfect for our data collection needs.",
        avatar: "MC"
    },
    {
        name: "Emily Davis",
        service: "hosting",
        rating: 5,
        text: "Switched from another provider and couldn't be happier. The migration was seamless and the performance improvement is noticeable.",
        avatar: "ED"
    },
    {
        name: "David Wilson",
        service: "traffic",
        rating: 5,
        text: "Amazing results! My e-commerce site traffic increased by 250% and conversions are up significantly. Great ROI!",
        avatar: "DW"
    },
    {
        name: "Lisa Anderson",
        service: "proxy",
        rating: 5,
        text: "Professional service with excellent customer support. The proxy speeds are consistent and the uptime is fantastic.",
        avatar: "LA"
    },
    {
        name: "Robert Taylor",
        service: "hosting",
        rating: 5,
        text: "Best hosting provider I've used. Fast loading times, reliable service, and competitive pricing. Five stars!",
        avatar: "RT"
    },
    {
        name: "Jennifer Brown",
        service: "traffic",
        rating: 5,
        text: "The targeted traffic service helped boost my blog's visibility. Quality visitors and improved search rankings!",
        avatar: "JB"
    },
    {
        name: "Mark Garcia",
        service: "proxy",
        rating: 5,
        text: "Reliable proxy service for our business needs. Great geographic coverage and excellent connection speeds.",
        avatar: "MG"
    },
    {
        name: "Amanda White",
        service: "hosting",
        rating: 5,
        text: "Outstanding hosting service! Easy setup, great control panel, and excellent technical support when needed.",
        avatar: "AW"
    },
    {
        name: "Chris Martinez",
        service: "traffic",
        rating: 5,
        text: "Impressive traffic generation results. My website analytics show consistent, quality traffic growth month over month.",
        avatar: "CM"
    },
    {
        name: "Rachel Lee",
        service: "proxy",
        rating: 5,
        text: "High-quality residential proxies with excellent anonymity. Perfect for our market research projects.",
        avatar: "RL"
    },
    {
        name: "Kevin Thompson",
        service: "hosting",
        rating: 5,
        text: "Reliable hosting with great uptime. The server response times are excellent and customer service is top-notch.",
        avatar: "KT"
    },
    {
        name: "Nicole Rodriguez",
        service: "traffic",
        rating: 5,
        text: "The organic traffic boost was exactly what my startup needed. Saw immediate improvements in website engagement.",
        avatar: "NR"
    },
    {
        name: "Steven Clark",
        service: "proxy",
        rating: 5,
        text: "Excellent proxy service for our enterprise needs. Stable connections and responsive customer support team.",
        avatar: "SC"
    },
    {
        name: "Michelle Lewis",
        service: "hosting",
        rating: 5,
        text: "Fantastic hosting experience! Easy migration, fast servers, and helpful support team. Couldn't ask for more.",
        avatar: "ML"
    },
    {
        name: "Daniel Walker",
        service: "traffic",
        rating: 5,
        text: "Great traffic generation service. Helped increase my website's visibility and improved search engine rankings.",
        avatar: "DW2"
    },
    {
        name: "Jessica Hall",
        service: "proxy",
        rating: 5,
        text: "Professional proxy service with excellent geographic distribution. Perfect for our international projects.",
        avatar: "JH"
    },
    {
        name: "Brian Young",
        service: "hosting",
        rating: 5,
        text: "Top-tier hosting service! Great performance, security features, and the best customer support I've experienced.",
        avatar: "BY"
    },
    {
        name: "Ashley King",
        service: "traffic",
        rating: 5,
        text: "The traffic quality is outstanding. Real visitors who actually engage with my content. Highly recommend!",
        avatar: "AK"
    }
];

// DOM Elements
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');
const reviewsGrid = document.getElementById('reviewsGrid');
const loadMoreBtn = document.getElementById('loadMoreReviews');
const filterBtns = document.querySelectorAll('.filter-btn');

// State
let currentFilter = 'all';
let reviewsShown = 6;

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    initNavigation();
    initReviews();
    initScrollAnimations();
    initPartnersSlider();
});

// Navigation functionality
function initNavigation() {
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });

        // Close menu when clicking on a link
        document.querySelectorAll('.nav-menu a').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
            });
        });
    }

    // Navbar scroll effect
    window.addEventListener('scroll', () => {
        const navbar = document.querySelector('.navbar');
        if (window.scrollY > 100) {
            navbar.style.background = 'rgba(255, 255, 255, 0.98)';
            navbar.style.boxShadow = '0 2px 20px rgba(0,0,0,0.1)';
        } else {
            navbar.style.background = 'rgba(255, 255, 255, 0.95)';
            navbar.style.boxShadow = 'none';
        }
    });
}

// Reviews functionality
function initReviews() {
    if (!reviewsGrid) return;

    // Filter buttons
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentFilter = btn.dataset.filter;
            reviewsShown = 6;
            displayReviews();
        });
    });

    // Load more button
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', () => {
            reviewsShown += 6;
            displayReviews();
        });
    }

    displayReviews();
}

function displayReviews() {
    if (!reviewsGrid) return;

    const filteredReviews = currentFilter === 'all' 
        ? reviewsData 
        : reviewsData.filter(review => review.service === currentFilter);

    const reviewsToShow = filteredReviews.slice(0, reviewsShown);

    reviewsGrid.innerHTML = reviewsToShow.map(review => `
        <div class="review-card">
            <div class="review-header">
                <div class="review-avatar">${review.avatar}</div>
                <div class="review-info">
                    <h4>${review.name}</h4>
                    <div class="review-rating">
                        ${'★'.repeat(review.rating)}
                    </div>
                </div>
            </div>
            <p class="review-text">${review.text}</p>
            <span class="review-service">${capitalizeFirst(review.service)}</span>
        </div>
    `).join('');

    // Update load more button
    if (loadMoreBtn) {
        if (reviewsToShow.length >= filteredReviews.length) {
            loadMoreBtn.style.display = 'none';
        } else {
            loadMoreBtn.style.display = 'block';
        }
    }
}

function capitalizeFirst(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

// Scroll animations
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe elements for animation
    const animateElements = document.querySelectorAll('.service-card, .portfolio-item, .review-card');
    animateElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
}

// Partners slider animation
function initPartnersSlider() {
    const partnersSlider = document.querySelector('.partners-slider');
    if (!partnersSlider) return;

    // Add hover pause functionality
    let isHovered = false;
    
    partnersSlider.addEventListener('mouseenter', () => {
        isHovered = true;
    });
    
    partnersSlider.addEventListener('mouseleave', () => {
        isHovered = false;
    });
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Add loading animation
function showLoading() {
    const loader = document.createElement('div');
    loader.className = 'loader';
    loader.innerHTML = `
        <div class="loader-spinner"></div>
        <p>Loading...</p>
    `;
    document.body.appendChild(loader);
    
    setTimeout(() => {
        loader.remove();
    }, 2000);
}

// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Add CSS for loader
const loaderCSS = `
.loader {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0.9);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    z-index: 10000;
}

.loader-spinner {
    width: 50px;
    height: 50px;
    border: 4px solid #f3f3f3;
    border-top: 4px solid #2563eb;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin-bottom: 1rem;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
`;

// Inject loader CSS
const style = document.createElement('style');
style.textContent = loaderCSS;
document.head.appendChild(style);

// Export functions for use in other pages
window.ProWebHosting = {
    showLoading,
    debounce,
    capitalizeFirst
};

