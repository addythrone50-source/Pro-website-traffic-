// Spark Traffic Page JavaScript

// Traffic-specific reviews data
const trafficReviews = [
    {
        name: "Sarah Johnson",
        service: "traffic",
        rating: 5,
        text: "The traffic generation service exceeded my expectations. I saw a 300% increase in organic visitors within the first month. Highly recommended!",
        avatar: "SJ"
    },
    {
        name: "David Wilson",
        service: "traffic",
        rating: 5,
        text: "Amazing results! My e-commerce site traffic increased by 250% and conversions are up significantly. Great ROI!",
        avatar: "DW"
    },
    {
        name: "Jennifer Brown",
        service: "traffic",
        rating: 5,
        text: "The targeted traffic service helped boost my blog's visibility. Quality visitors and improved search rankings!",
        avatar: "JB"
    },
    {
        name: "Chris Martinez",
        service: "traffic",
        rating: 5,
        text: "Impressive traffic generation results. My website analytics show consistent, quality traffic growth month over month.",
        avatar: "CM"
    },
    {
        name: "Nicole Rodriguez",
        service: "traffic",
        rating: 5,
        text: "The organic traffic boost was exactly what my startup needed. Saw immediate improvements in website engagement.",
        avatar: "NR"
    },
    {
        name: "Daniel Walker",
        service: "traffic",
        rating: 5,
        text: "Great traffic generation service. Helped increase my website's visibility and improved search engine rankings.",
        avatar: "DW2"
    },
    {
        name: "Ashley King",
        service: "traffic",
        rating: 5,
        text: "The traffic quality is outstanding. Real visitors who actually engage with my content. Highly recommend!",
        avatar: "AK"
    },
    {
        name: "Michael Torres",
        service: "traffic",
        rating: 5,
        text: "Excellent service! My website traffic doubled in just 3 weeks. The targeting options are very precise.",
        avatar: "MT"
    }
];

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    initTrafficStats();
    initPurchaseButtons();
    initTrafficReviews();
    initAnimatedCounters();
});

// Initialize traffic statistics
function initTrafficStats() {
    // Animate counters
    animateCounter('totalVisitors', 15847);
    animateCounter('clickRate', 8.7, '%');
    animateCounter('avgTime', 4.2, 'm');
    animateCounter('countries', 45);
    
    // Initialize traffic chart (placeholder)
    initTrafficChart();
}

// Animate counter numbers
function animateCounter(elementId, targetValue, suffix = '') {
    const element = document.getElementById(elementId);
    if (!element) return;
    
    let currentValue = 0;
    const increment = targetValue / 100;
    const duration = 2000; // 2 seconds
    const stepTime = duration / 100;
    
    const timer = setInterval(() => {
        currentValue += increment;
        if (currentValue >= targetValue) {
            currentValue = targetValue;
            clearInterval(timer);
        }
        
        if (suffix === '%' || suffix === 'm') {
            element.textContent = currentValue.toFixed(1) + suffix;
        } else {
            element.textContent = Math.floor(currentValue).toLocaleString() + suffix;
        }
    }, stepTime);
}

// Initialize traffic chart
function initTrafficChart() {
    const canvas = document.getElementById('trafficChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // Simple chart visualization
    const width = canvas.width = canvas.offsetWidth;
    const height = canvas.height = canvas.offsetHeight;
    
    // Generate sample data
    const data = [];
    for (let i = 0; i < 24; i++) {
        data.push(Math.random() * 1000 + 500);
    }
    
    // Draw chart
    ctx.clearRect(0, 0, width, height);
    
    // Draw grid
    ctx.strokeStyle = '#e5e7eb';
    ctx.lineWidth = 1;
    
    for (let i = 0; i <= 10; i++) {
        const y = (height / 10) * i;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
    }
    
    // Draw line chart
    ctx.strokeStyle = '#2563eb';
    ctx.lineWidth = 3;
    ctx.beginPath();
    
    const stepX = width / (data.length - 1);
    const maxValue = Math.max(...data);
    
    data.forEach((value, index) => {
        const x = index * stepX;
        const y = height - (value / maxValue) * height;
        
        if (index === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });
    
    ctx.stroke();
    
    // Draw points
    ctx.fillStyle = '#2563eb';
    data.forEach((value, index) => {
        const x = index * stepX;
        const y = height - (value / maxValue) * height;
        
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, Math.PI * 2);
        ctx.fill();
    });
    
    // Add labels
    ctx.fillStyle = '#666';
    ctx.font = '12px Poppins';
    ctx.textAlign = 'center';
    
    for (let i = 0; i < 24; i += 4) {
        const x = (i / (data.length - 1)) * width;
        ctx.fillText(i + ':00', x, height - 10);
    }
}

// Initialize purchase buttons
function initPurchaseButtons() {
    const purchaseButtons = document.querySelectorAll('.btn-purchase');
    
    purchaseButtons.forEach(button => {
        button.addEventListener('click', function() {
            const service = this.dataset.service;
            const price = this.dataset.price;
            
            // Show loading state
            const originalText = this.textContent;
            this.textContent = 'Processing...';
            this.disabled = true;
            
            // Simulate processing
            setTimeout(() => {
                // Redirect to payment page with service info
                const params = new URLSearchParams({
                    service: service,
                    price: price,
                    type: 'traffic'
                });
                window.location.href = `payment.html?${params.toString()}`;
            }, 1500);
        });
    });
}

// Initialize traffic reviews
function initTrafficReviews() {
    const reviewsContainer = document.getElementById('trafficReviews');
    if (!reviewsContainer) return;
    
    const reviewsToShow = trafficReviews.slice(0, 6);
    
    reviewsContainer.innerHTML = reviewsToShow.map(review => `
        <div class="review-card">
            <div class="review-header">
                <div class="review-avatar">${review.avatar}</div>
                <div class="review-info">
                    <h4>${review.name}</h4>
                    <div class="review-rating">
                        ${'★'.repeat(review.rating)}
                    </div>
                </div>
            </div>
            <p class="review-text">${review.text}</p>
            <span class="review-service">Traffic Generation</span>
        </div>
    `).join('');
}

// Initialize animated counters when in viewport
function initAnimatedCounters() {
    const counterElements = document.querySelectorAll('.stat-info h3');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !entry.target.classList.contains('animated')) {
                entry.target.classList.add('animated');
                
                // Re-trigger animations
                const elementId = entry.target.id;
                if (elementId) {
                    switch(elementId) {
                        case 'totalVisitors':
                            animateCounter('totalVisitors', 15847);
                            break;
                        case 'clickRate':
                            animateCounter('clickRate', 8.7, '%');
                            break;
                        case 'avgTime':
                            animateCounter('avgTime', 4.2, 'm');
                            break;
                        case 'countries':
                            animateCounter('countries', 45);
                            break;
                    }
                }
            }
        });
    }, { threshold: 0.5 });
    
    counterElements.forEach(el => observer.observe(el));
}

// Service pricing data (for admin panel)
window.sparkTrafficPricing = {
    organic: { name: "Organic Web Visitors", price: 49, description: "Up to 10,000 visitors" },
    analytics: { name: "Real-time Analytics", price: 29, description: "Advanced analytics suite" },
    bounce: { name: "Bounce Rate Reduction", price: 39, description: "Engagement optimization" },
    geo: { name: "GEO Targeted Traffic", price: 59, description: "Targeted by location" },
    niche: { name: "Niche-Specific Visitors", price: 69, description: "Niche audience targeting" },
    time: { name: "Time-On-Site Optimization", price: 45, description: "Engagement optimization" }
};

// Update pricing (for admin panel)
function updateServicePricing(serviceId, newPrice) {
    if (window.sparkTrafficPricing[serviceId]) {
        window.sparkTrafficPricing[serviceId].price = newPrice;
        
        // Update DOM
        const serviceCard = document.querySelector(`[data-service="${serviceId}"]`);
        if (serviceCard) {
            const priceElement = serviceCard.querySelector('.price');
            const buttonElement = serviceCard.querySelector('.btn-purchase');
            
            if (priceElement) priceElement.textContent = `$${newPrice}`;
            if (buttonElement) buttonElement.dataset.price = newPrice;
        }
        
        return true;
    }
    return false;
}

// Export functions for admin panel
window.SparkTrafficAdmin = {
    updateServicePricing,
    getPricingData: () => window.sparkTrafficPricing
};

