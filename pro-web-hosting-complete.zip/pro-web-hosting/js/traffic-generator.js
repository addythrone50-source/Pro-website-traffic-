// Traffic Generator Page JavaScript

// Available countries data
const availableCountries = {
    'US': { name: 'United States', flag: '🇺🇸' },
    'GB': { name: 'United Kingdom', flag: '🇬🇧' },
    'CA': { name: 'Canada', flag: '🇨🇦' },
    'AU': { name: 'Australia', flag: '🇦🇺' },
    'DE': { name: 'Germany', flag: '🇩🇪' },
    'FR': { name: 'France', flag: '🇫🇷' },
    'IT': { name: 'Italy', flag: '🇮🇹' },
    'ES': { name: 'Spain', flag: '🇪🇸' },
    'NL': { name: 'Netherlands', flag: '🇳🇱' },
    'SE': { name: 'Sweden', flag: '🇸🇪' },
    'NO': { name: 'Norway', flag: '🇳🇴' },
    'DK': { name: 'Denmark', flag: '🇩🇰' },
    'FI': { name: 'Finland', flag: '🇫🇮' },
    'CH': { name: 'Switzerland', flag: '🇨🇭' },
    'AT': { name: 'Austria', flag: '🇦🇹' },
    'BE': { name: 'Belgium', flag: '🇧🇪' },
    'IE': { name: 'Ireland', flag: '🇮🇪' },
    'PT': { name: 'Portugal', flag: '🇵🇹' },
    'GR': { name: 'Greece', flag: '🇬🇷' },
    'PL': { name: 'Poland', flag: '🇵🇱' },
    'CZ': { name: 'Czech Republic', flag: '🇨🇿' },
    'HU': { name: 'Hungary', flag: '🇭🇺' },
    'RO': { name: 'Romania', flag: '🇷🇴' },
    'BG': { name: 'Bulgaria', flag: '🇧🇬' },
    'HR': { name: 'Croatia', flag: '🇭🇷' },
    'SI': { name: 'Slovenia', flag: '🇸🇮' },
    'SK': { name: 'Slovakia', flag: '🇸🇰' },
    'LT': { name: 'Lithuania', flag: '🇱🇹' },
    'LV': { name: 'Latvia', flag: '🇱🇻' },
    'EE': { name: 'Estonia', flag: '🇪🇪' },
    'JP': { name: 'Japan', flag: '🇯🇵' },
    'KR': { name: 'South Korea', flag: '🇰🇷' },
    'SG': { name: 'Singapore', flag: '🇸🇬' },
    'HK': { name: 'Hong Kong', flag: '🇭🇰' },
    'TW': { name: 'Taiwan', flag: '🇹🇼' },
    'MY': { name: 'Malaysia', flag: '🇲🇾' },
    'TH': { name: 'Thailand', flag: '🇹🇭' },
    'PH': { name: 'Philippines', flag: '🇵🇭' },
    'ID': { name: 'Indonesia', flag: '🇮🇩' },
    'VN': { name: 'Vietnam', flag: '🇻🇳' },
    'IN': { name: 'India', flag: '🇮🇳' },
    'BR': { name: 'Brazil', flag: '🇧🇷' },
    'MX': { name: 'Mexico', flag: '🇲🇽' },
    'AR': { name: 'Argentina', flag: '🇦🇷' },
    'CL': { name: 'Chile', flag: '🇨🇱' },
    'CO': { name: 'Colombia', flag: '🇨🇴' },
    'PE': { name: 'Peru', flag: '🇵🇪' },
    'ZA': { name: 'South Africa', flag: '🇿🇦' },
    'EG': { name: 'Egypt', flag: '🇪🇬' },
    'IL': { name: 'Israel', flag: '🇮🇱' },
    'TR': { name: 'Turkey', flag: '🇹🇷' },
    'RU': { name: 'Russia', flag: '🇷🇺' },
    'UA': { name: 'Ukraine', flag: '🇺🇦' }
};

// State variables
let selectedCountries = ['US', 'GB', 'CA'];
let isTrafficRunning = false;
let trafficInterval;
let liveStats = {
    visitors: 0,
    clicks: 0,
    session: 4.2,
    conversion: 2.8
};

// Initialize page
document.addEventListener('DOMContentLoaded', function() {
    initTrafficForm();
    initCountrySelection();
    initAdvancedSettings();
    initTrafficPreview();
    initOTPModal();
});

// Initialize traffic form
function initTrafficForm() {
    const form = document.getElementById('trafficForm');
    const trafficRange = document.getElementById('trafficRange');
    const trafficValue = document.getElementById('trafficValue');
    const validateBtn = document.getElementById('validateUrl');
    const urlInput = document.getElementById('websiteUrl');
    
    // Traffic range slider
    if (trafficRange && trafficValue) {
        trafficRange.addEventListener('input', function() {
            const value = parseInt(this.value);
            trafficValue.textContent = (value / 1000).toFixed(0) + 'K';
            if (value >= 1000000) {
                trafficValue.textContent = (value / 1000000).toFixed(1) + 'M';
            }
        });
    }
    
    // URL validation
    if (validateBtn && urlInput) {
        validateBtn.addEventListener('click', function() {
            validateURL(urlInput.value);
        });
        
        urlInput.addEventListener('input', function() {
            clearURLStatus();
        });
    }
    
    // Form submission
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            handleFormSubmission();
        });
    }
}

// Validate URL
function validateURL(url) {
    const urlStatus = document.getElementById('urlStatus');
    const validateBtn = document.getElementById('validateUrl');
    
    if (!urlStatus || !validateBtn) return;
    
    // Show loading
    validateBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    validateBtn.disabled = true;
    
    setTimeout(() => {
        try {
            new URL(url);
            urlStatus.innerHTML = '<i class="fas fa-check-circle"></i> URL is valid and accessible';
            urlStatus.className = 'url-status valid';
            validateBtn.innerHTML = '<i class="fas fa-check"></i>';
            validateBtn.style.background = '#10b981';
        } catch (error) {
            urlStatus.innerHTML = '<i class="fas fa-exclamation-circle"></i> Please enter a valid URL';
            urlStatus.className = 'url-status invalid';
            validateBtn.innerHTML = '<i class="fas fa-times"></i>';
            validateBtn.style.background = '#ef4444';
        }
        
        validateBtn.disabled = false;
    }, 1500);
}

// Clear URL status
function clearURLStatus() {
    const urlStatus = document.getElementById('urlStatus');
    const validateBtn = document.getElementById('validateUrl');
    
    if (urlStatus) {
        urlStatus.innerHTML = '';
        urlStatus.className = 'url-status';
    }
    
    if (validateBtn) {
        validateBtn.innerHTML = '<i class="fas fa-check"></i>';
        validateBtn.style.background = '#10b981';
        validateBtn.disabled = false;
    }
}

// Initialize country selection
function initCountrySelection() {
    const addCountryBtn = document.getElementById('addCountry');
    const selectedCountriesContainer = document.getElementById('selectedCountries');
    
    if (addCountryBtn) {
        addCountryBtn.addEventListener('click', showCountrySelector);
    }
    
    // Initialize remove buttons
    updateCountryTags();
}

// Update country tags
function updateCountryTags() {
    const container = document.getElementById('selectedCountries');
    if (!container) return;
    
    container.innerHTML = selectedCountries.map(countryCode => {
        const country = availableCountries[countryCode];
        return `
            <div class="country-tag" data-country="${countryCode}">
                <span>${country.flag} ${country.name}</span>
                <button type="button" class="remove-country" onclick="removeCountry('${countryCode}')">×</button>
            </div>
        `;
    }).join('');
}

// Show country selector
function showCountrySelector() {
    const availableList = Object.keys(availableCountries)
        .filter(code => !selectedCountries.includes(code))
        .map(code => {
            const country = availableCountries[code];
            return `<option value="${code}">${country.flag} ${country.name}</option>`;
        }).join('');
    
    if (availableList) {
        const select = document.createElement('select');
        select.innerHTML = `<option value="">Select a country...</option>${availableList}`;
        select.style.cssText = `
            padding: 0.5rem;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            margin-left: 1rem;
        `;
        
        select.addEventListener('change', function() {
            if (this.value) {
                addCountry(this.value);
                this.remove();
            }
        });
        
        const addBtn = document.getElementById('addCountry');
        addBtn.parentNode.insertBefore(select, addBtn.nextSibling);
        select.focus();
    }
}

// Add country
function addCountry(countryCode) {
    if (!selectedCountries.includes(countryCode)) {
        selectedCountries.push(countryCode);
        updateCountryTags();
    }
}

// Remove country
function removeCountry(countryCode) {
    selectedCountries = selectedCountries.filter(code => code !== countryCode);
    updateCountryTags();
}

// Initialize advanced settings
function initAdvancedSettings() {
    const toggleBtn = document.getElementById('toggleAdvanced');
    const advancedSettings = document.getElementById('advancedSettings');
    
    if (toggleBtn && advancedSettings) {
        toggleBtn.addEventListener('click', function() {
            const isVisible = advancedSettings.classList.contains('show');
            
            if (isVisible) {
                advancedSettings.classList.remove('show');
                this.classList.remove('active');
            } else {
                advancedSettings.classList.add('show');
                this.classList.add('active');
            }
        });
    }
}

// Handle form submission
function handleFormSubmission() {
    const urlInput = document.getElementById('websiteUrl');
    const trafficRange = document.getElementById('trafficRange');
    
    if (!urlInput || !trafficRange) return;
    
    const url = urlInput.value.trim();
    const trafficAmount = parseInt(trafficRange.value);
    
    if (!url) {
        alert('Please enter a website URL');
        return;
    }
    
    // Validate URL format
    try {
        new URL(url);
    } catch (error) {
        alert('Please enter a valid URL');
        return;
    }
    
    // Show OTP modal
    showOTPModal();
}

// Initialize OTP modal
function initOTPModal() {
    const verifyBtn = document.getElementById('verifyOtp');
    const cancelBtn = document.getElementById('cancelOtp');
    const otpInput = document.getElementById('otpInput');
    
    if (verifyBtn) {
        verifyBtn.addEventListener('click', verifyOTP);
    }
    
    if (cancelBtn) {
        cancelBtn.addEventListener('click', hideOTPModal);
    }
    
    if (otpInput) {
        otpInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                verifyOTP();
            }
        });
    }
}

// Show OTP modal
function showOTPModal() {
    const modal = document.getElementById('otpModal');
    if (modal) {
        modal.style.display = 'flex';
        
        const otpInput = document.getElementById('otpInput');
        if (otpInput) {
            setTimeout(() => otpInput.focus(), 100);
        }
    }
}

// Hide OTP modal
function hideOTPModal() {
    const modal = document.getElementById('otpModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

// Verify OTP
function verifyOTP() {
    const otpInput = document.getElementById('otpInput');
    const verifyBtn = document.getElementById('verifyOtp');
    
    if (!otpInput || !verifyBtn) return;
    
    const enteredOTP = otpInput.value.trim();
    const correctOTP = '123456';
    
    verifyBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verifying...';
    verifyBtn.disabled = true;
    
    setTimeout(() => {
        if (enteredOTP === correctOTP) {
            hideOTPModal();
            startTrafficGeneration();
        } else {
            showOTPError();
            verifyBtn.innerHTML = 'Start Traffic';
            verifyBtn.disabled = false;
        }
    }, 2000);
}

// Show OTP error
function showOTPError() {
    const otpInput = document.getElementById('otpInput');
    if (otpInput) {
        otpInput.style.borderColor = '#ef4444';
        otpInput.style.backgroundColor = '#fef2f2';
        
        setTimeout(() => {
            otpInput.style.borderColor = '#e5e7eb';
            otpInput.style.backgroundColor = 'white';
        }, 3000);
    }
}

// Start traffic generation
function startTrafficGeneration() {
    isTrafficRunning = true;
    
    // Show success notification
    showTrafficStartNotification();
    
    // Start live traffic simulation
    startLiveTrafficSimulation();
    
    // Update form state
    const generateBtn = document.querySelector('.btn-generate-traffic');
    if (generateBtn) {
        generateBtn.innerHTML = '<i class="fas fa-stop"></i> Stop Traffic';
        generateBtn.onclick = stopTrafficGeneration;
    }
}

// Stop traffic generation
function stopTrafficGeneration() {
    isTrafficRunning = false;
    
    if (trafficInterval) {
        clearInterval(trafficInterval);
    }
    
    const generateBtn = document.querySelector('.btn-generate-traffic');
    if (generateBtn) {
        generateBtn.innerHTML = '<i class="fas fa-rocket"></i> Generate Traffic';
        generateBtn.onclick = null;
        generateBtn.type = 'submit';
    }
    
    // Reset stats
    liveStats = { visitors: 0, clicks: 0, session: 4.2, conversion: 2.8 };
    updateLiveStats();
}

// Show traffic start notification
function showTrafficStartNotification() {
    const notification = document.createElement('div');
    notification.innerHTML = `
        <div style="
            position: fixed;
            top: 100px;
            right: 20px;
            background: white;
            border: 1px solid #10b981;
            border-radius: 15px;
            padding: 1rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            z-index: 10001;
            min-width: 300px;
        ">
            <div style="display: flex; align-items: center; gap: 1rem;">
                <i class="fas fa-rocket" style="color: #10b981; font-size: 2rem;"></i>
                <div>
                    <h4 style="color: #10b981; margin: 0 0 0.3rem 0;">Traffic Generation Started!</h4>
                    <p style="color: #666; margin: 0; font-size: 0.9rem;">Your traffic campaign is now live and running.</p>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 5000);
}

// Initialize traffic preview
function initTrafficPreview() {
    initLiveTrafficChart();
    updateLiveStats();
}

// Initialize live traffic chart
function initLiveTrafficChart() {
    const canvas = document.getElementById('liveTrafficChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // Set canvas size
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    
    drawTrafficChart(ctx, canvas.width, canvas.height);
}

// Draw traffic chart
function drawTrafficChart(ctx, width, height) {
    ctx.clearRect(0, 0, width, height);
    
    // Generate sample data
    const data = [];
    for (let i = 0; i < 24; i++) {
        const baseValue = isTrafficRunning ? Math.random() * 500 + 200 : Math.random() * 100 + 50;
        data.push(baseValue);
    }
    
    // Draw grid
    ctx.strokeStyle = '#e5e7eb';
    ctx.lineWidth = 1;
    
    for (let i = 0; i <= 10; i++) {
        const y = (height / 10) * i;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
    }
    
    // Draw line chart
    ctx.strokeStyle = isTrafficRunning ? '#10b981' : '#2563eb';
    ctx.lineWidth = 3;
    ctx.beginPath();
    
    const stepX = width / (data.length - 1);
    const maxValue = Math.max(...data);
    
    data.forEach((value, index) => {
        const x = index * stepX;
        const y = height - (value / maxValue) * height * 0.8;
        
        if (index === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });
    
    ctx.stroke();
    
    // Draw points
    ctx.fillStyle = isTrafficRunning ? '#10b981' : '#2563eb';
    data.forEach((value, index) => {
        const x = index * stepX;
        const y = height - (value / maxValue) * height * 0.8;
        
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, Math.PI * 2);
        ctx.fill();
    });
}

// Start live traffic simulation
function startLiveTrafficSimulation() {
    trafficInterval = setInterval(() => {
        if (isTrafficRunning) {
            // Update stats
            liveStats.visitors += Math.floor(Math.random() * 50) + 10;
            liveStats.clicks += Math.floor(Math.random() * 20) + 5;
            liveStats.session = 4.2 + (Math.random() - 0.5) * 2;
            liveStats.conversion = 2.8 + (Math.random() - 0.5) * 1.5;
            
            updateLiveStats();
            
            // Redraw chart
            const canvas = document.getElementById('liveTrafficChart');
            if (canvas) {
                const ctx = canvas.getContext('2d');
                drawTrafficChart(ctx, canvas.width, canvas.height);
            }
        }
    }, 2000);
}

// Update live stats
function updateLiveStats() {
    const elements = {
        liveVisitors: document.getElementById('liveVisitors'),
        liveClicks: document.getElementById('liveClicks'),
        liveSession: document.getElementById('liveSession'),
        liveConversion: document.getElementById('liveConversion')
    };
    
    if (elements.liveVisitors) {
        elements.liveVisitors.textContent = liveStats.visitors.toLocaleString();
    }
    
    if (elements.liveClicks) {
        elements.liveClicks.textContent = liveStats.clicks.toLocaleString();
    }
    
    if (elements.liveSession) {
        elements.liveSession.textContent = liveStats.session.toFixed(1) + 'm';
    }
    
    if (elements.liveConversion) {
        elements.liveConversion.textContent = liveStats.conversion.toFixed(1) + '%';
    }
}

// Make functions globally available
window.removeCountry = removeCountry;
window.addCountry = addCountry;

